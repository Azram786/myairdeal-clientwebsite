import React from "react";

const Ticket = () => {
  return <div>Ticket</div>;
};

export default Ticket;
