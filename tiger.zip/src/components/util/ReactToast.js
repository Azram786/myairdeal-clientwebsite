import { toast } from "react-toastify";


const ReactToast = (message) => {
  toast(message);
};

export default ReactToast;
